Pengujian dilakukan pada akun koperasi yang baru didaftarkan untuk membuat request pengambilan barang.

Hasil pencarian barang pada formulir Buat Request Pengambilan Baru ditampilkan dalam kotak berwarna putih tanpa kontras warna teks yang memadai, sehingga nama barang tidak dapat terbaca dengan jelas oleh pengguna.

![](images/image1.png)

Pengujian yang sama dilakukan pada akun Koperasi Unit Jasa B, dan permasalahan keterbacaan pada hasil pencarian barang di formulir request masih ditemukan.

Meskipun demikian, proses pengajuan request pengambilan barang tetap dapat diselesaikan dan disubmit dengan baik.

Namun, pada akun ini fitur pengajuan retur barang belum dapat diakses atau digunakan.

![](images/image2.png)

Pada halaman Request Pengambilan Saya milik akun Koperasi Unit Jasa B, ditemukan kendala tampilan berupa judul kolom dan isi data (No. Request serta Tanggal) yang tidak terlihat jelas karena warna teks yang hampir menyatu dengan latar belakang.

![](images/image3.png)

Pengujian pengajuan request pengambilan barang oleh akun koperasi baru menghasilkan pesan kegagalan "Failed to create request: User is not an active member of this warehouse", yang menunjukkan bahwa akun tersebut belum berstatus anggota aktif pada gudang terkait.

![](images/image4.png)

Pengajuan retur barang oleh akun Koperasi Unit Produksi berhasil dibuat dengan status "Submitted", namun pada halaman detail retur, nilai data seperti No. Pengambilan, Koperasi, Alasan, dan Catatan Koperasi tidak terlihat jelas akibat warna teks yang tidak kontras dengan latar belakang.

![](images/image5.png)

Pada beberapa halaman, termasuk Dashboard Purchasing, ditemukan bahwa sistem melakukan pembaruan (refresh) data secara otomatis, sehingga terkadang mengganggu proses pengisian data yang belum selesai dilakukan oleh pengguna.

![](images/image6.png)

Saat fitur Laporan diakses oleh akun Purchasing, sistem menampilkan halaman error "403 Forbidden", yang menandakan pengguna tidak memiliki hak akses ke fitur tersebut.

![](images/image7.png)

Pengujian penambahan data supplier oleh akun Purchasing berhasil dilakukan, ditandai dengan notifikasi "Supplier berhasil ditambahkan" pada halaman Master Supplier / Pemasok.

![](images/image8.png)

Pengujian pembuatan request pengambilan barang oleh akun Purchasing berhasil dilakukan, ditandai dengan notifikasi "Request successfully created and submitted!" dan status request "Menunggu Approval".

![](images/image9.png)

Pengujian pencatatan penerimaan barang (receipts) oleh akun Purchasing berhasil dilakukan, ditandai dengan notifikasi "Penerimaan barang berhasil dicatat" beserta rincian purchase order, penerima, dan status quality control (QC) untuk setiap item.

![](images/image10.png)

Pengujian penambahan barang baru pada Katalog Barang Gudang oleh akun Staff Admin berhasil dilakukan, ditandai dengan notifikasi "Barang master berhasil ditambahkan".

![](images/image11.png)

Pengujian pencatatan transaksi stok oleh akun Staff Admin berhasil dilakukan, dan riwayat mutasi stok dapat dilihat secara lengkap pada halaman Ledger Transaksi Stok (Append-Only).

![](images/image12.png)

Pengujian penambahan data lokasi dan zona rak barang oleh akun Staff Admin berhasil dilakukan, dan data lokasi rak berhasil ditampilkan dengan status "Aktif" pada halaman Lokasi & Zona Rak Gudang.

![](images/image13.png)