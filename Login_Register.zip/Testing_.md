Pengujian login menggunakan akun App Admin berhasil dilakukan, dan sistem berhasil menampilkan halaman Dashboard Administrasi Gudang Utama Logistik.

![](images/image1.png)

Pengujian login menggunakan akun Koperasi Unit Jasa B berhasil dilakukan, dan sistem menampilkan halaman Beranda Gudang Utama Logistik beserta ringkasan status request dan jadwal pengambilan barang.

![](images/image2.png)

Proses registrasi akun koperasi baru (koperasi_cece) berhasil dilakukan, dan pengguna berhasil login serta diarahkan ke halaman Dashboard Administrasi dengan status satu pengguna aktif dan satu membership aktif.

![](images/image3.png)

Pengujian login menggunakan akun Koperasi Unit Produksi (Kop1) berhasil dilakukan, dan sistem menampilkan halaman Beranda Gudang Utama Logistik beserta ringkasan request dan retur terbaru.

![](images/image4.png)

Pengujian login menggunakan akun Staff Admin berhasil dilakukan, dan sistem menampilkan halaman Dashboard Staff Admin yang memuat ringkasan tugas pengambilan barang serta daftar purchase request yang sedang berjalan.

![](images/image5.png)

Pengujian login menggunakan akun kepala gudang berhasil dilakukan, dan sistem menampilkan halaman Dashboard kepala gudang yang memuat ringkasan tugas sedang berjalan.

![](images/image6.png)